# 16. ENSAIO DO COTIDIANO

Categoria: Habilidades sociais e cotidiano
Público: 5+ e adultos

## REFERÊNCIA VISUAL
Utilizar como imagem-guia a prévia apresentada ao lado do recurso no atlas ou, preferencialmente, o arquivo original anexado. A referência é uma direção visual; coordenadas a seguir são proposta inicial de reconstrução, sujeitas a calibração visual.

## GEOMETRIA E CÂMERA
Ambiente: 22 × 16 × 4.5 m, supermercado realista modular.
Câmera: FOV 65° em modo pessoa, altura 1,4–1,65 m conforme perfil; overview FOV 38° em (14,9,18).
Paleta e iluminação: prateleiras brancas, pisos cinza-quente, produtos coloridos mas agrupados, teto difuso.

## MAPA ESPACIAL DOS OBJETOS
Entrada em (0,0,7). Quatro corredores paralelos no eixo Z em X=-7,-2,3,8. Checkout com esteira no fundo direito (8,0,-7). Balcão de informação à esquerda (-9,0,-7); depósito parcialmente visível atrás. Corredores com largura mínima visual 1,8m.

## MESHES E ASSETS QUE DEVEM SER MODELADOS
Carrinho com rodízios, cestinha, vinte tipos de produtos reutilizando modelos base e rótulos fictícios, prateleiras com volumes instanciados, refrigeradores com portas e gôndolas, caixa, esteira e sinalizações HTML de navegação.

## MATERIAIS, TEXTURAS E ACABAMENTOS
Piso vinílico roughness 0,65; prateleiras metal pintado; caixa de papel com fibras; frutas com roughness variável, embalagens brilhantes moderadas; iluminação fluorescente simulada por áreas de luz com sombra pré-computada.

## INTERAÇÕES, REGRAS E FEEDBACK
Explorar em primeira pessoa ou vista elevada, selecionar lista visual, localizar produtos, pedir informação, esperar na fila, finalizar compra simulada sem valores reais e praticar mudanças inesperadas configuráveis; sem exposição obrigatória a multidões/ruídos.

## ÁUDIO
Refrigeração e murmúrios em volume baixo, opção silêncio total, sem sustos e sem anúncios automáticos.

## TECNOLOGIA E SISTEMAS ESPECÍFICOS
Three.js pointer lock somente desktop com alternativa joystick touch; navegação em malha/navmesh, NPCs com caminhos curtos, instancing e occlusion culling; estados por tarefas.

## PROMPT INDIVIDUAL PARA GOOGLE NANO BANANA
Supermercado contemporâneo 3D muito realista em perspectiva aérea três-quartos, entrada e quatro corredores organizados de prateleiras com produtos fictícios, área de caixa no fundo direito com esteira, balcão de informação à esquerda, carrinho e iluminação de teto difusa, texturas PBR, sem marcas comerciais, sem nomes legíveis, 16:9.

## CRITÉRIOS DE ACEITAÇÃO
1. Cena realmente tridimensional, não apenas fundo estático em 2D; câmera, peças e volumes coerentes com a referência.
2. Cada objeto principal possui ID, posição, rotação, escala, material e função no manifesto da cena.
3. Interface completa em português com navegação por teclado/toque; áudio opcional e controle de intensidade.
4. Ações executadas têm efeito visual e lógico verificável; estado pode ser reiniciado e salvo quando apropriado.
5. Captura lado a lado (referência vs implementação), ajuste da câmera e relatório de divergências.
6. Modo baixo desempenho, sem efeitos que provoquem estímulos inesperados; sem resultados diagnósticos automáticos.

---

# CONTRATO GLOBAL DE PRODUÇÃO — APLICÁVEL A TODOS OS RECURSOS

Desenvolva uma aplicação navegável em HTML5 + CSS3 + JavaScript/TypeScript, com Three.js, executável em navegador desktop e mobile. Use Vite como empacotador (ou arquivos HTML/JS como alternativa se o protótipo for isolado). Modelos devem ser glTF 2.0/GLB, com texturas PBR (baseColor/sRGB; normal, roughness, metallic e AO em espaço linear). Ative renderer.outputColorSpace = THREE.SRGBColorSpace e toneMapping = THREE.ACESFilmicToneMapping ou perfil visual equivalente aferido por capturas. Evite luzes dinâmicas em excesso: use environment map HDRI comprimido, uma key light, luzes complementares seletivas, sombras suavizadas e lightmaps para geometria estática. Não confunda iluminação renderizada em uma imagem com luz 3D real.

Coordenadas: X para a direita, Y para cima, Z para profundidade; piso Y=0; metros virtuais. Os objetos e dimensões abaixo são alvos iniciais para reconstrução, NÃO medições extraídas dos pixels da imagem. Preservar silhueta, proporção, paleta, enquadramento e hierarquia dos volumes presentes na referência anexada; calibrar com comparações lado a lado. Câmera com OrbitControls limitados, movimento suave e zoom/clamps para não atravessar objetos; controles por toque, mouse, teclado, e alternativa acessível por botões. UI externa ao canvas em HTML sem textos embutidos em textura; usar hitboxes generosas, foco visível, legenda, botão sair, pausar, reduzir movimento, silenciar e reiniciar.

Os assets devem ser produzidos em pipeline: (1) imagem-guia no Nano Banana; (2) texturas e decalques separados sem texto; (3) modelagem 3D em Blender ou glTF procedural; (4) UV, material, colisores, LOD; (5) exportação GLB e compressão. Nano Banana gera referência 2D, NÃO malha 3D com rig e colisões. Para itens interativos exigir geometria individual, pivô ajustado, nomes semânticos e estados de animação idle/hover/selected/active. Não transformar a imagem completa da sala num plano 2D que simula 3D.

Metas iniciais de desempenho (ajustáveis após profiling): 60fps desktop de referência, degradação elegante para 30fps mobile; geometria em cena preferencialmente abaixo de 200k-450k triângulos mobile / 750k desktop; 1–2k mapas por material compartilhado, 4k somente peças hero desktop; instancing e LOD para repetidos; KTX2/Basis e Draco ou Meshopt onde conveniente; draw calls alvo <150 mobile e <300 desktop. Carregar sob demanda e eliminar renderização permanente em cenas estáticas. Não presumir que todos os dispositivos suportam WebGPU; WebGL2 como base. Usar Rapier somente para corpos físicos reais, não adicionar motor de física a cada objeto decorativo.

Dados terapêuticos: toda atividade deve ser não diagnóstica por padrão; eventos observáveis descritos sem inferências automáticas sobre transtornos. Não criar rótulos, percentis, escalas clínicas nem interpretações simbólicas fixas sem instrumento/estudo válido. Consentimento e configuração de retenção dos dados, proteção de dados de crianças e opção de sessão anônima. Não enviar vozes, vídeos, relatos clínicos ou dados pessoais ao serviço de geração visual.

ENTREGAS POR RECURSO: index.html ou rota + source TS/JS + styles + manifesto de assets + arquivo scene.json com coordenadas + módulos de interação, áudio e estado + fallback mobile/2D + testes de acessibilidade e funcionamento + README. Criar mockup comparativo referência-versus-render em duas capturas com mesma câmera e anotar divergências antes de finalizar. Se as imagens de referência não estiverem disponíveis como arquivo, não reivindicar fidelidade pixel a pixel; solicitar/imprimir o campo de upload e preservar o prompt visual até recebê-las.
