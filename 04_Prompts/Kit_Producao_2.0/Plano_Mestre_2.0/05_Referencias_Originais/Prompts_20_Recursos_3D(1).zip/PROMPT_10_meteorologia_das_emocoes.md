# 10. METEOROLOGIA DAS EMOÇÕES

Categoria: Emoções e autorregulação
Público: 4+ e adultos

## REFERÊNCIA VISUAL
Utilizar como imagem-guia a prévia apresentada ao lado do recurso no atlas ou, preferencialmente, o arquivo original anexado. A referência é uma direção visual; coordenadas a seguir são proposta inicial de reconstrução, sujeitas a calibração visual.

## GEOMETRIA E CÂMERA
Ambiente: 14 × 10 × 8 m, estufa poética sob cúpula.
Câmera: FOV 40°, câmera (10,7,13) mirando (0,2,0).
Paleta e iluminação: vidro claro, cobre, areia, azul e cinza de nuvens, verde natural.

## MAPA ESPACIAL DOS OBJETOS
Jardim circular de raio 5 m sob estufa de vidro. Cúpula em (0,0,0) com topo Y=7,5; ilha central de grama e riacho em (0,0,0). Quatro colunas climáticas nos quadrantes X/Z ±3 guardam controles de sol, nuvem, chuva e vento. Banco em (-3,0,1), pequena árvore em (2,0,-2).

## MESHES E ASSETS QUE DEVEM SER MODELADOS
Cúpula com varetas de cobre, nuvens volumétricas low-poly suavizadas, gotas de chuva controladas, sol difuso representado por disco no céu, plumas de vento, pequenas plantas, caminhos de pedra e cartões de metáforas.

## MATERIAIS, TEXTURAS E ACABAMENTOS
Vidro com reflexos seletivos, metal de cobre, folhas translucência simulada; partículas translúcidas pequenas para chuva; nuvens shader dithered/volumetria falsa de baixa carga, evitando nuvens densas caras.

## INTERAÇÕES, REGRAS E FEEDBACK
Escolher combinações de clima como metáfora do estado atual, graduar cada componente, narrar o motivo, registrar mudanças, reconstruir versões anteriores, criar clima impossível sem erro; sem mapear emoções de forma fixa.

## ÁUDIO
Vento, chuva e folhas com controles de ganho separados, sem trovoadas ou picos inesperados.

## TECNOLOGIA E SISTEMAS ESPECÍFICOS
Three.js; shader procedimental leve para céu e nuvem; partículas instanciadas; animação climática com transições suaves e opção reduzir movimento.

## PROMPT INDIVIDUAL PARA GOOGLE NANO BANANA
Estufa de vidro geodésica realista com jardim circular, pequena árvore e banco, teto alto com nuvens suaves, chuva delicada, raios solares difusos e vento simbolizado por folhas; quatro pedestais ao redor, materiais vidro-cobre-pedra, atmosfera poética, alta qualidade PBR, sem relâmpagos, sem texto, 16:9.

## CRITÉRIOS DE ACEITAÇÃO
1. Cena realmente tridimensional, não apenas fundo estático em 2D; câmera, peças e volumes coerentes com a referência.
2. Cada objeto principal possui ID, posição, rotação, escala, material e função no manifesto da cena.
3. Interface completa em português com navegação por teclado/toque; áudio opcional e controle de intensidade.
4. Ações executadas têm efeito visual e lógico verificável; estado pode ser reiniciado e salvo quando apropriado.
5. Captura lado a lado (referência vs implementação), ajuste da câmera e relatório de divergências.
6. Modo baixo desempenho, sem efeitos que provoquem estímulos inesperados; sem resultados diagnósticos automáticos.

---

# CONTRATO GLOBAL DE PRODUÇÃO — APLICÁVEL A TODOS OS RECURSOS

Desenvolva uma aplicação navegável em HTML5 + CSS3 + JavaScript/TypeScript, com Three.js, executável em navegador desktop e mobile. Use Vite como empacotador (ou arquivos HTML/JS como alternativa se o protótipo for isolado). Modelos devem ser glTF 2.0/GLB, com texturas PBR (baseColor/sRGB; normal, roughness, metallic e AO em espaço linear). Ative renderer.outputColorSpace = THREE.SRGBColorSpace e toneMapping = THREE.ACESFilmicToneMapping ou perfil visual equivalente aferido por capturas. Evite luzes dinâmicas em excesso: use environment map HDRI comprimido, uma key light, luzes complementares seletivas, sombras suavizadas e lightmaps para geometria estática. Não confunda iluminação renderizada em uma imagem com luz 3D real.

Coordenadas: X para a direita, Y para cima, Z para profundidade; piso Y=0; metros virtuais. Os objetos e dimensões abaixo são alvos iniciais para reconstrução, NÃO medições extraídas dos pixels da imagem. Preservar silhueta, proporção, paleta, enquadramento e hierarquia dos volumes presentes na referência anexada; calibrar com comparações lado a lado. Câmera com OrbitControls limitados, movimento suave e zoom/clamps para não atravessar objetos; controles por toque, mouse, teclado, e alternativa acessível por botões. UI externa ao canvas em HTML sem textos embutidos em textura; usar hitboxes generosas, foco visível, legenda, botão sair, pausar, reduzir movimento, silenciar e reiniciar.

Os assets devem ser produzidos em pipeline: (1) imagem-guia no Nano Banana; (2) texturas e decalques separados sem texto; (3) modelagem 3D em Blender ou glTF procedural; (4) UV, material, colisores, LOD; (5) exportação GLB e compressão. Nano Banana gera referência 2D, NÃO malha 3D com rig e colisões. Para itens interativos exigir geometria individual, pivô ajustado, nomes semânticos e estados de animação idle/hover/selected/active. Não transformar a imagem completa da sala num plano 2D que simula 3D.

Metas iniciais de desempenho (ajustáveis após profiling): 60fps desktop de referência, degradação elegante para 30fps mobile; geometria em cena preferencialmente abaixo de 200k-450k triângulos mobile / 750k desktop; 1–2k mapas por material compartilhado, 4k somente peças hero desktop; instancing e LOD para repetidos; KTX2/Basis e Draco ou Meshopt onde conveniente; draw calls alvo <150 mobile e <300 desktop. Carregar sob demanda e eliminar renderização permanente em cenas estáticas. Não presumir que todos os dispositivos suportam WebGPU; WebGL2 como base. Usar Rapier somente para corpos físicos reais, não adicionar motor de física a cada objeto decorativo.

Dados terapêuticos: toda atividade deve ser não diagnóstica por padrão; eventos observáveis descritos sem inferências automáticas sobre transtornos. Não criar rótulos, percentis, escalas clínicas nem interpretações simbólicas fixas sem instrumento/estudo válido. Consentimento e configuração de retenção dos dados, proteção de dados de crianças e opção de sessão anônima. Não enviar vozes, vídeos, relatos clínicos ou dados pessoais ao serviço de geração visual.

ENTREGAS POR RECURSO: index.html ou rota + source TS/JS + styles + manifesto de assets + arquivo scene.json com coordenadas + módulos de interação, áudio e estado + fallback mobile/2D + testes de acessibilidade e funcionamento + README. Criar mockup comparativo referência-versus-render em duas capturas com mesma câmera e anotar divergências antes de finalizar. Se as imagens de referência não estiverem disponíveis como arquivo, não reivindicar fidelidade pixel a pixel; solicitar/imprimir o campo de upload e preservar o prompt visual até recebê-las.
