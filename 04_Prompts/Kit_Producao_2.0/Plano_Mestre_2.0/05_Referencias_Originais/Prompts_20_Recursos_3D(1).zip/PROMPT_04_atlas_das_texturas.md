# 04. ATLAS DAS TEXTURAS

Categoria: Percepção e processamento sensorial
Público: 3+ e adultos

## REFERÊNCIA VISUAL
Utilizar como imagem-guia a prévia apresentada ao lado do recurso no atlas ou, preferencialmente, o arquivo original anexado. A referência é uma direção visual; coordenadas a seguir são proposta inicial de reconstrução, sujeitas a calibração visual.

## GEOMETRIA E CÂMERA
Ambiente: 11 × 8 m, galeria com oito pedestais.
Câmera: FOV 39°, câmera (8,5.2,10) mirando (0,1.1,0).
Paleta e iluminação: paredes creme, piso areia, madeira natural, metais neutros e objetos em cores de material real.

## MAPA ESPACIAL DOS OBJETOS
Sala retangular com oito pedestais, quatro de cada lado em X=±3,2, Z=-2,7,-0,8,1,1,3. Uma bancada de exame em (0,0,0) mede 2 × 1 m. A parede de fundo exibe quadrados táteis sem legenda impressa; interface explica o material ao selecionar.

## MESHES E ASSETS QUE DEVEM SER MODELADOS
Objetos de veludo, argila, vidro, madeira, metal escovado, pedra, couro vegetal e areia simulada. Cada objeto tem uma versão ampliada rotacionável e uma amostra de superfície esférica ou cúbica. Pedestais de calcário com borda arredondada.

## MATERIAIS, TEXTURAS E ACABAMENTOS
Veludo com sheen e trama em normal; madeira com veios orientados e roughness 0,55; cerâmica roughness 0,38 com micro-arranhões; vidro transmission; metal metalness 0,9 e roughness 0,28; pedra roughness 0,9 e displacement muito discreto.

## INTERAÇÕES, REGRAS E FEEDBACK
Arrastar objeto para bancada, girar em 360°, zoom de macro, alternar luz rasante para revelar relevo, agrupar materiais por preferências, associar lembranças, salvar coleção; opção com materiais físicos reais mediada pelo terapeuta.

## ÁUDIO
Som de manuseio opcional para algumas superfícies, intensidade sempre reduzida; legenda e controle individual.

## TECNOLOGIA E SISTEMAS ESPECÍFICOS
OrbitControls por objeto, SSAO econômico, texturas anisotrópicas, KTX2, PBR com normal map; instancing dos pedestais.

## PROMPT INDIVIDUAL PARA GOOGLE NANO BANANA
Museu realista de materiais com oito pedestais de pedra em duas fileiras simétricas, amostras isoladas de veludo, madeira, cerâmica, vidro, metal, pedra, couro vegetal e areia; bancada central de inspeção, luz suave de galeria e destaques rasantes para mostrar microtexturas PBR, estética contemplativa premium, vista isométrica, sem texto, 16:9. Gerar amostras de baseColor, roughness/normal de cada matéria em arquivos separados seamless.

## CRITÉRIOS DE ACEITAÇÃO
1. Cena realmente tridimensional, não apenas fundo estático em 2D; câmera, peças e volumes coerentes com a referência.
2. Cada objeto principal possui ID, posição, rotação, escala, material e função no manifesto da cena.
3. Interface completa em português com navegação por teclado/toque; áudio opcional e controle de intensidade.
4. Ações executadas têm efeito visual e lógico verificável; estado pode ser reiniciado e salvo quando apropriado.
5. Captura lado a lado (referência vs implementação), ajuste da câmera e relatório de divergências.
6. Modo baixo desempenho, sem efeitos que provoquem estímulos inesperados; sem resultados diagnósticos automáticos.

---

# CONTRATO GLOBAL DE PRODUÇÃO — APLICÁVEL A TODOS OS RECURSOS

Desenvolva uma aplicação navegável em HTML5 + CSS3 + JavaScript/TypeScript, com Three.js, executável em navegador desktop e mobile. Use Vite como empacotador (ou arquivos HTML/JS como alternativa se o protótipo for isolado). Modelos devem ser glTF 2.0/GLB, com texturas PBR (baseColor/sRGB; normal, roughness, metallic e AO em espaço linear). Ative renderer.outputColorSpace = THREE.SRGBColorSpace e toneMapping = THREE.ACESFilmicToneMapping ou perfil visual equivalente aferido por capturas. Evite luzes dinâmicas em excesso: use environment map HDRI comprimido, uma key light, luzes complementares seletivas, sombras suavizadas e lightmaps para geometria estática. Não confunda iluminação renderizada em uma imagem com luz 3D real.

Coordenadas: X para a direita, Y para cima, Z para profundidade; piso Y=0; metros virtuais. Os objetos e dimensões abaixo são alvos iniciais para reconstrução, NÃO medições extraídas dos pixels da imagem. Preservar silhueta, proporção, paleta, enquadramento e hierarquia dos volumes presentes na referência anexada; calibrar com comparações lado a lado. Câmera com OrbitControls limitados, movimento suave e zoom/clamps para não atravessar objetos; controles por toque, mouse, teclado, e alternativa acessível por botões. UI externa ao canvas em HTML sem textos embutidos em textura; usar hitboxes generosas, foco visível, legenda, botão sair, pausar, reduzir movimento, silenciar e reiniciar.

Os assets devem ser produzidos em pipeline: (1) imagem-guia no Nano Banana; (2) texturas e decalques separados sem texto; (3) modelagem 3D em Blender ou glTF procedural; (4) UV, material, colisores, LOD; (5) exportação GLB e compressão. Nano Banana gera referência 2D, NÃO malha 3D com rig e colisões. Para itens interativos exigir geometria individual, pivô ajustado, nomes semânticos e estados de animação idle/hover/selected/active. Não transformar a imagem completa da sala num plano 2D que simula 3D.

Metas iniciais de desempenho (ajustáveis após profiling): 60fps desktop de referência, degradação elegante para 30fps mobile; geometria em cena preferencialmente abaixo de 200k-450k triângulos mobile / 750k desktop; 1–2k mapas por material compartilhado, 4k somente peças hero desktop; instancing e LOD para repetidos; KTX2/Basis e Draco ou Meshopt onde conveniente; draw calls alvo <150 mobile e <300 desktop. Carregar sob demanda e eliminar renderização permanente em cenas estáticas. Não presumir que todos os dispositivos suportam WebGPU; WebGL2 como base. Usar Rapier somente para corpos físicos reais, não adicionar motor de física a cada objeto decorativo.

Dados terapêuticos: toda atividade deve ser não diagnóstica por padrão; eventos observáveis descritos sem inferências automáticas sobre transtornos. Não criar rótulos, percentis, escalas clínicas nem interpretações simbólicas fixas sem instrumento/estudo válido. Consentimento e configuração de retenção dos dados, proteção de dados de crianças e opção de sessão anônima. Não enviar vozes, vídeos, relatos clínicos ou dados pessoais ao serviço de geração visual.

ENTREGAS POR RECURSO: index.html ou rota + source TS/JS + styles + manifesto de assets + arquivo scene.json com coordenadas + módulos de interação, áudio e estado + fallback mobile/2D + testes de acessibilidade e funcionamento + README. Criar mockup comparativo referência-versus-render em duas capturas com mesma câmera e anotar divergências antes de finalizar. Se as imagens de referência não estiverem disponíveis como arquivo, não reivindicar fidelidade pixel a pixel; solicitar/imprimir o campo de upload e preservar o prompt visual até recebê-las.
