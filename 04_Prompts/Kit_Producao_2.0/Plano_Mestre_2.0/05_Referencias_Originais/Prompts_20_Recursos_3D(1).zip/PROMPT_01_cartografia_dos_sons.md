# 01. CARTOGRAFIA DOS SONS

Categoria: Percepção e processamento sensorial
Público: 5+ e adultos

## REFERÊNCIA VISUAL
Utilizar como imagem-guia a prévia apresentada ao lado do recurso no atlas ou, preferencialmente, o arquivo original anexado. A referência é uma direção visual; coordenadas a seguir são proposta inicial de reconstrução, sujeitas a calibração visual.

## GEOMETRIA E CÂMERA
Ambiente: 30 × 24 m, maquete urbana aberta, ruas na cota Y=0.
Câmera: ortográfica aparente, perspectiva real FOV 34°, câmera (21,19,26) mirando (0,0,0), azimute 40°.
Paleta e iluminação: alvenaria creme, telhas terracota, asfalto cinza-azulado, folhagens verde-musgo, luz matinal 4800 K.

## MAPA ESPACIAL DOS OBJETOS
A praça central ocupa (0,0,0) com raio 4 m e piso de placas de pedra. A cafeteria de fachada creme fica (-9,0,-5), com toldo listrado e três mesas externas. Escola de dois pavimentos em (8,0,-7), com janelas retangulares e portão gradeado. Parque arborizado em (-9,0,7), contendo bancos, arbustos e um chafariz discreto. Ponto de ônibus em (9,0,6); rua contorna o conjunto com meio-fio, faixa de pedestre, postes e um único carro opcional.

## MESHES E ASSETS QUE DEVEM SER MODELADOS
Cafeteria: porta de madeira com dobradiças, vidros com IOR aproximado 1,5, xícaras e máquina de café como objetos de cena; escola: 16 janelas repetidas via instancing; parque: 6 árvores de três geometrias, folhas por atlas alfa, chão grama; ponto: abrigo metálico, banco, painel; praça: fonte, jardineiras, ladrilhos; cinco ícones discretos de fonte sonora apenas quando selecionados.

## MATERIAIS, TEXTURAS E ACABAMENTOS
Paredes com reboco microgranulado roughness 0,83; paralelepípedo normal map sutil 0,85; vidro com transmissão moderada e fallback opaco mobile; asfalto roughness 0,95 e decalques pintados; madeira PBR roughness 0,65; árvores com variação de verde e translucência simulada.

## INTERAÇÕES, REGRAS E FEEDBACK
Clique/toque em cada fonte da cidade para escutar prévia opcional; regular volume e desligar de imediato; arrastar fonte no mapa para comparar posição; alternar isolamento e mistura de fontes; marcar agradável/neutro/desconfortável/não sei; personalizar distância sonora, cenário e registro textual; pausar tudo com botão fixo. Nunca aumentar volume automaticamente.

## ÁUDIO
Web Audio API: fonte por PannerNode HRTF; GainNode por categoria; limitador de ganho e botão de silêncio; sons inicia apenas por ação explícita e gradualmente com fade curto; sons de pássaros, vozes simuladas, tráfego, chuva, água e cafeteria em arquivos separados.

## TECNOLOGIA E SISTEMAS ESPECÍFICOS
Three.js Raycaster, scene graph por quarteirão, LOD nas árvores, AudioListener na câmera, shader de vento leve; mapa de fontes em JSON; Web Audio com PannerNode/GainNode.

## PROMPT INDIVIDUAL PARA GOOGLE NANO BANANA
Use a imagem fornecida como referência visual primária. Render 3D altamente realista de maquete urbana interativa acolhedora, vista isométrica três-quartos: praça central de pedras, cafeteria creme à esquerda com toldo e mesas, escola à direita ao fundo, parque verde à esquerda à frente, abrigo de ônibus à direita à frente, rua de asfalto ao redor; luz matinal cálida, sombras suaves, materiais PBR e detalhes de miniatura premium; composição limpa que permita identificar cada origem de som; sem pessoas identificáveis, sem texto, sem logotipos, 16:9, 4k. Gerar em seguida separado: fachadas, decalques, folhas e ícones em PNG transparente; texturas seamless de reboco, asfalto e placas de piso.

## CRITÉRIOS DE ACEITAÇÃO
1. Cena realmente tridimensional, não apenas fundo estático em 2D; câmera, peças e volumes coerentes com a referência.
2. Cada objeto principal possui ID, posição, rotação, escala, material e função no manifesto da cena.
3. Interface completa em português com navegação por teclado/toque; áudio opcional e controle de intensidade.
4. Ações executadas têm efeito visual e lógico verificável; estado pode ser reiniciado e salvo quando apropriado.
5. Captura lado a lado (referência vs implementação), ajuste da câmera e relatório de divergências.
6. Modo baixo desempenho, sem efeitos que provoquem estímulos inesperados; sem resultados diagnósticos automáticos.

---

# CONTRATO GLOBAL DE PRODUÇÃO — APLICÁVEL A TODOS OS RECURSOS

Desenvolva uma aplicação navegável em HTML5 + CSS3 + JavaScript/TypeScript, com Three.js, executável em navegador desktop e mobile. Use Vite como empacotador (ou arquivos HTML/JS como alternativa se o protótipo for isolado). Modelos devem ser glTF 2.0/GLB, com texturas PBR (baseColor/sRGB; normal, roughness, metallic e AO em espaço linear). Ative renderer.outputColorSpace = THREE.SRGBColorSpace e toneMapping = THREE.ACESFilmicToneMapping ou perfil visual equivalente aferido por capturas. Evite luzes dinâmicas em excesso: use environment map HDRI comprimido, uma key light, luzes complementares seletivas, sombras suavizadas e lightmaps para geometria estática. Não confunda iluminação renderizada em uma imagem com luz 3D real.

Coordenadas: X para a direita, Y para cima, Z para profundidade; piso Y=0; metros virtuais. Os objetos e dimensões abaixo são alvos iniciais para reconstrução, NÃO medições extraídas dos pixels da imagem. Preservar silhueta, proporção, paleta, enquadramento e hierarquia dos volumes presentes na referência anexada; calibrar com comparações lado a lado. Câmera com OrbitControls limitados, movimento suave e zoom/clamps para não atravessar objetos; controles por toque, mouse, teclado, e alternativa acessível por botões. UI externa ao canvas em HTML sem textos embutidos em textura; usar hitboxes generosas, foco visível, legenda, botão sair, pausar, reduzir movimento, silenciar e reiniciar.

Os assets devem ser produzidos em pipeline: (1) imagem-guia no Nano Banana; (2) texturas e decalques separados sem texto; (3) modelagem 3D em Blender ou glTF procedural; (4) UV, material, colisores, LOD; (5) exportação GLB e compressão. Nano Banana gera referência 2D, NÃO malha 3D com rig e colisões. Para itens interativos exigir geometria individual, pivô ajustado, nomes semânticos e estados de animação idle/hover/selected/active. Não transformar a imagem completa da sala num plano 2D que simula 3D.

Metas iniciais de desempenho (ajustáveis após profiling): 60fps desktop de referência, degradação elegante para 30fps mobile; geometria em cena preferencialmente abaixo de 200k-450k triângulos mobile / 750k desktop; 1–2k mapas por material compartilhado, 4k somente peças hero desktop; instancing e LOD para repetidos; KTX2/Basis e Draco ou Meshopt onde conveniente; draw calls alvo <150 mobile e <300 desktop. Carregar sob demanda e eliminar renderização permanente em cenas estáticas. Não presumir que todos os dispositivos suportam WebGPU; WebGL2 como base. Usar Rapier somente para corpos físicos reais, não adicionar motor de física a cada objeto decorativo.

Dados terapêuticos: toda atividade deve ser não diagnóstica por padrão; eventos observáveis descritos sem inferências automáticas sobre transtornos. Não criar rótulos, percentis, escalas clínicas nem interpretações simbólicas fixas sem instrumento/estudo válido. Consentimento e configuração de retenção dos dados, proteção de dados de crianças e opção de sessão anônima. Não enviar vozes, vídeos, relatos clínicos ou dados pessoais ao serviço de geração visual.

ENTREGAS POR RECURSO: index.html ou rota + source TS/JS + styles + manifesto de assets + arquivo scene.json com coordenadas + módulos de interação, áudio e estado + fallback mobile/2D + testes de acessibilidade e funcionamento + README. Criar mockup comparativo referência-versus-render em duas capturas com mesma câmera e anotar divergências antes de finalizar. Se as imagens de referência não estiverem disponíveis como arquivo, não reivindicar fidelidade pixel a pixel; solicitar/imprimir o campo de upload e preservar o prompt visual até recebê-las.
